/* */
#include <asm/types.h>


int main(void){return 0;}

