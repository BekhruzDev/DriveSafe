/* */
#include <sys/time.h>


int main(void){return 0;}

