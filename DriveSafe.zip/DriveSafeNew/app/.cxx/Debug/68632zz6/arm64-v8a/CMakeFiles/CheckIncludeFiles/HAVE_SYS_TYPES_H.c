/* */
#include <sys/types.h>


int main(void){return 0;}

