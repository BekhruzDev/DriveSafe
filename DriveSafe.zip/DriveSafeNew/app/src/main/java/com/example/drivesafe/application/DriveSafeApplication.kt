package com.example.drivesafe.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DriveSafeApplication:Application()